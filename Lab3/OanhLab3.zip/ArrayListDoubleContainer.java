import java.util.*;

public class ArrayListDoubleContainer extends DoubleContainer
{
    public ArrayListDoubleContainer(){
        super.data = new ArrayList<Double>();
    }
    
}
