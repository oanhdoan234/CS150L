import java.util.*;

public class LinkedListDoubleContainer extends DoubleContainer
{
    public LinkedListDoubleContainer(){
        super.data = new LinkedList<Double>();
    }
    
}
