
public class Hotel<K extends Comparable<K>> extends Node<K>
{

    public Hotel(K k){
        super(k);
    }
    
    
}
