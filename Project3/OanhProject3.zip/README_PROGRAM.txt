/** 
 *	CS150 - Project 3
 *  Author: Oanh Doan 
 */

The program can be run by compiling Controller.java and specifying the names of city's map and sites' labels. 
	- For example: javac Controller.java; java Controller cityA.txt sitesA.txt

Once the program runs, it will display sites and hotels of the map. Users are prompted to give inputs in the following order: 
	- Starting node
	- Time limit
	- Desired sites
Inputs are separated by tabs. 


